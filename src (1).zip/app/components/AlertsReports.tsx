import { useState } from "react";
import { AlertTriangle, AlertCircle, Info, CheckCircle, Bell, BellOff, Download, Clock, Filter, X } from "lucide-react";

const alerts = [
  { id: 1, type: "critical", title: "Critical Stock Depletion", message: "Steel Cable 10mm 50m (IN-2290-ST) at 12 units — 4 days remaining at current velocity. Immediate reorder required.", time: "2 min ago", sku: "IN-2290-ST", warehouse: "WH-05 Detroit", acknowledged: false },
  { id: 2, type: "critical", title: "Critical Stock Depletion", message: "Waterproof Jacket M (AP-8812-BL) at 48 units — stock will deplete in 6 days without reorder.", time: "18 min ago", sku: "AP-8812-BL", warehouse: "WH-03 Seattle", acknowledged: false },
  { id: 3, type: "warning", title: "Low Stock Warning", message: "USB-C Hub 7-Port (EL-5512-WH) at 141 units — below reorder point of 150. On-order shipment expected in 14 days.", time: "1h ago", sku: "EL-5512-WH", warehouse: "WH-02 Dallas", acknowledged: false },
  { id: 4, type: "warning", title: "Supplier Delivery Delay", message: "FastFab Electronics (SUP-005) order #PO-20261104 delayed by 5 days. New ETA: June 28.", time: "3h ago", sku: null, warehouse: null, acknowledged: true },
  { id: 5, type: "warning", title: "Warehouse Capacity Alert", message: "WH-04 Atlanta at 89% capacity. Consider rerouting inbound shipments or initiating transfers.", time: "5h ago", sku: null, warehouse: "WH-04 Atlanta", acknowledged: false },
  { id: 6, type: "info", title: "Demand Spike Detected", message: "Wireless Earbuds Pro (EL-4401-GR) showing 47% velocity increase over 7-day average. Forecast updated.", time: "8h ago", sku: "EL-4401-GR", warehouse: null, acknowledged: true },
  { id: 7, type: "info", title: "Supplier Onboarded", message: "New supplier 'PacificEdge Manufacturing' (SUP-291) has completed vetting and is now approved.", time: "12h ago", sku: null, warehouse: null, acknowledged: true },
  { id: 8, type: "success", title: "Reorder Fulfilled", message: "PO-20261098 for Laptop Pro 15\" (400 units) received at WH-01 Chicago. Quality check passed.", time: "1d ago", sku: "EL-9284-BK", warehouse: "WH-01 Chicago", acknowledged: true },
  { id: 9, type: "success", title: "Monthly Report Generated", message: "May 2026 Supply Chain Performance Report is ready for download.", time: "1d ago", sku: null, warehouse: null, acknowledged: true },
  { id: 10, type: "warning", title: "Lead Time Increase", message: "GlobalThread Co. notified lead time increasing from 28 to 35 days for next quarter.", time: "2d ago", sku: null, warehouse: null, acknowledged: true },
];

const reports = [
  { name: "June 2026 Stock Report", type: "Stock", size: "2.4 MB", format: "PDF", date: "Jun 16, 2026" },
  { name: "Q2 2026 Supply Chain KPIs", type: "Performance", size: "5.1 MB", format: "XLSX", date: "Jun 15, 2026" },
  { name: "Supplier Scorecard — H1 2026", type: "Supplier", size: "3.8 MB", format: "PDF", date: "Jun 14, 2026" },
  { name: "Demand Forecast Report Q3", type: "Forecast", size: "1.9 MB", format: "PDF", date: "Jun 12, 2026" },
  { name: "Warehouse Utilization May 2026", type: "Warehouse", size: "4.2 MB", format: "XLSX", date: "Jun 10, 2026" },
];

const alertConfig = {
  critical: { color: "#ef4444", bg: "rgba(239,68,68,0.1)", border: "rgba(239,68,68,0.2)", icon: AlertCircle, label: "Critical" },
  warning: { color: "#f59e0b", bg: "rgba(245,158,11,0.1)", border: "rgba(245,158,11,0.2)", icon: AlertTriangle, label: "Warning" },
  info: { color: "#06b6d4", bg: "rgba(6,182,212,0.1)", border: "rgba(6,182,212,0.2)", icon: Info, label: "Info" },
  success: { color: "#10b981", bg: "rgba(16,185,129,0.1)", border: "rgba(16,185,129,0.2)", icon: CheckCircle, label: "Success" },
};

export function AlertsReports() {
  const [filterType, setFilterType] = useState("all");
  const [showAcknowledged, setShowAcknowledged] = useState(false);
  const [localAlerts, setLocalAlerts] = useState(alerts);

  const acknowledge = (id: number) => {
    setLocalAlerts(prev => prev.map(a => a.id === id ? { ...a, acknowledged: true } : a));
  };

  const filtered = localAlerts.filter(a => {
    const typeMatch = filterType === "all" || a.type === filterType;
    const ackMatch = showAcknowledged || !a.acknowledged;
    return typeMatch && ackMatch;
  });

  const unackCount = localAlerts.filter(a => !a.acknowledged).length;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-foreground" style={{ fontSize: "1.4rem", fontWeight: 700 }}>Alerts & Reports</h1>
          <p className="text-muted-foreground" style={{ fontSize: "0.85rem", marginTop: "2px" }}>
            {unackCount > 0
              ? <span><span style={{ color: "#ef4444", fontFamily: "var(--font-mono)", fontWeight: 600 }}>{unackCount}</span> unacknowledged alerts require attention</span>
              : "All alerts acknowledged"}
          </p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card border border-border text-muted-foreground hover:text-foreground transition-colors" style={{ fontSize: "0.8rem" }}>
          <Bell className="w-3.5 h-3.5" />
          Configure Alerts
        </button>
      </div>

      {/* Alert Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {(["critical", "warning", "info", "success"] as const).map(type => {
          const cfg = alertConfig[type];
          const Icon = cfg.icon;
          const count = localAlerts.filter(a => a.type === type).length;
          return (
            <button
              key={type}
              onClick={() => setFilterType(filterType === type ? "all" : type)}
              className="bg-card border rounded-xl p-4 text-left transition-all duration-150 hover:opacity-80"
              style={{ borderColor: filterType === type ? cfg.color : "rgba(6,182,212,0.12)" }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-lg" style={{ background: cfg.bg }}>
                  <Icon className="w-4 h-4" style={{ color: cfg.color }} />
                </div>
                <span style={{ fontFamily: "var(--font-mono)", fontSize: "1.3rem", fontWeight: 700, color: cfg.color }}>{count}</span>
              </div>
              <p className="text-muted-foreground" style={{ fontSize: "0.75rem" }}>{cfg.label} Alerts</p>
            </button>
          );
        })}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex gap-1">
          {["all", "critical", "warning", "info", "success"].map(t => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded-lg border transition-colors capitalize ${filterType === t ? "bg-primary/20 border-primary/30 text-primary" : "bg-card border-border text-muted-foreground hover:text-foreground"}`}
              style={{ fontSize: "0.75rem" }}
            >
              {t}
            </button>
          ))}
        </div>
        <button
          onClick={() => setShowAcknowledged(!showAcknowledged)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-colors ${showAcknowledged ? "bg-secondary border-border text-foreground" : "bg-card border-border text-muted-foreground"}`}
          style={{ fontSize: "0.75rem" }}
        >
          {showAcknowledged ? <Bell className="w-3.5 h-3.5" /> : <BellOff className="w-3.5 h-3.5" />}
          {showAcknowledged ? "Hide Acknowledged" : "Show Acknowledged"}
        </button>
      </div>

      {/* Alert List */}
      <div className="space-y-2.5">
        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <CheckCircle className="w-10 h-10 text-accent mb-3" />
            <p className="text-foreground" style={{ fontSize: "0.95rem", fontWeight: 500 }}>No alerts to show</p>
            <p className="text-muted-foreground" style={{ fontSize: "0.83rem" }}>All clear for selected filter</p>
          </div>
        )}
        {filtered.map(alert => {
          const cfg = alertConfig[alert.type as keyof typeof alertConfig];
          const Icon = cfg.icon;
          return (
            <div
              key={alert.id}
              className={`flex gap-4 p-4 rounded-xl border transition-all duration-200 ${alert.acknowledged ? "opacity-50" : ""}`}
              style={{ background: cfg.bg, borderColor: cfg.border }}
            >
              <div className="flex items-start justify-center w-8 h-8 rounded-lg shrink-0 mt-0.5" style={{ background: `rgba(0,0,0,0.2)` }}>
                <Icon className="w-4 h-4 mt-2" style={{ color: cfg.color }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-foreground" style={{ fontSize: "0.85rem", fontWeight: 600 }}>{alert.title}</p>
                    <p className="text-muted-foreground mt-1" style={{ fontSize: "0.78rem", lineHeight: 1.5 }}>{alert.message}</p>
                  </div>
                  {!alert.acknowledged && (
                    <button
                      onClick={() => acknowledge(alert.id)}
                      className="shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-card/50 border border-border text-muted-foreground hover:text-foreground transition-colors"
                      style={{ fontSize: "0.72rem" }}
                    >
                      <X className="w-3 h-3" />
                      Ack
                    </button>
                  )}
                </div>
                <div className="flex items-center gap-3 mt-2 flex-wrap">
                  <div className="flex items-center gap-1 text-muted-foreground" style={{ fontSize: "0.7rem" }}>
                    <Clock className="w-3 h-3" />
                    {alert.time}
                  </div>
                  {alert.sku && (
                    <span className="px-1.5 py-0.5 rounded bg-card/60 text-muted-foreground" style={{ fontFamily: "var(--font-mono)", fontSize: "0.68rem", color: "#06b6d4" }}>{alert.sku}</span>
                  )}
                  {alert.warehouse && (
                    <span className="px-1.5 py-0.5 rounded bg-card/60 text-muted-foreground" style={{ fontSize: "0.68rem" }}>{alert.warehouse}</span>
                  )}
                  {alert.acknowledged && (
                    <span className="text-muted-foreground" style={{ fontSize: "0.68rem" }}>✓ Acknowledged</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Reports Section */}
      <div className="bg-card border border-border rounded-xl p-5 mt-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-foreground" style={{ fontSize: "0.95rem", fontWeight: 600 }}>Generated Reports</h3>
          <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/15 border border-primary/20 text-primary hover:bg-primary/25 transition-colors" style={{ fontSize: "0.78rem" }}>
            <Filter className="w-3 h-3" />
            Generate New
          </button>
        </div>
        <div className="space-y-2.5">
          {reports.map(report => (
            <div key={report.name} className="flex items-center gap-4 p-3.5 rounded-xl bg-secondary/50 border border-border/50 hover:border-border transition-colors group">
              <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-secondary border border-border shrink-0">
                <span style={{ fontSize: "0.65rem", fontWeight: 700, color: report.format === "PDF" ? "#ef4444" : "#10b981", fontFamily: "var(--font-mono)" }}>{report.format}</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-foreground" style={{ fontSize: "0.83rem", fontWeight: 500 }}>{report.name}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="px-1.5 py-0.5 rounded bg-secondary text-muted-foreground" style={{ fontSize: "0.68rem" }}>{report.type}</span>
                  <span className="text-muted-foreground" style={{ fontSize: "0.68rem" }}>{report.size}</span>
                  <span className="text-muted-foreground" style={{ fontSize: "0.68rem" }}>•</span>
                  <span className="text-muted-foreground" style={{ fontSize: "0.68rem" }}>{report.date}</span>
                </div>
              </div>
              <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-card border border-border text-muted-foreground opacity-0 group-hover:opacity-100 hover:text-foreground transition-all" style={{ fontSize: "0.75rem" }}>
                <Download className="w-3.5 h-3.5" />
                Download
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
