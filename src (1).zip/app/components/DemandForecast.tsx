import { useState } from "react";
import { Brain, TrendingUp, TrendingDown, Minus, Calendar, RefreshCw } from "lucide-react";
import {
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  ReferenceLine,
} from "recharts";

const forecastData = [
  { period: "Jan", actual: 4200, forecast: 4100, lower: 3800, upper: 4400 },
  { period: "Feb", actual: 3800, forecast: 3900, lower: 3600, upper: 4200 },
  { period: "Mar", actual: 5200, forecast: 5000, lower: 4700, upper: 5300 },
  { period: "Apr", actual: 4600, forecast: 4800, lower: 4500, upper: 5100 },
  { period: "May", actual: 6100, forecast: 5900, lower: 5600, upper: 6200 },
  { period: "Jun", actual: 5400, forecast: 5700, lower: 5400, upper: 6000 },
  { period: "Jul", actual: null, forecast: 6800, lower: 6400, upper: 7200 },
  { period: "Aug", actual: null, forecast: 7400, lower: 6900, upper: 7900 },
  { period: "Sep", actual: null, forecast: 6900, lower: 6400, upper: 7400 },
  { period: "Oct", actual: null, forecast: 7800, lower: 7200, upper: 8400 },
  { period: "Nov", actual: null, forecast: 9200, lower: 8600, upper: 9800 },
  { period: "Dec", actual: null, forecast: 10400, lower: 9700, upper: 11100 },
];

const skuForecasts = [
  { sku: "EL-9284-BK", name: "Laptop Pro 15\"", currentDemand: 284, forecastedDemand: 342, change: 20.4, confidence: 91, trend: "up", suggestedOrder: 500 },
  { sku: "AP-3341-SM", name: "Running Shorts XS-XL", currentDemand: 241, forecastedDemand: 318, change: 32.0, confidence: 87, trend: "up", suggestedOrder: 800 },
  { sku: "FB-0022-CS", name: "Cold Brew Coffee 12pk", currentDemand: 198, forecastedDemand: 167, change: -15.7, confidence: 83, trend: "down", suggestedOrder: 200 },
  { sku: "IN-7731-MT", name: "M8 Hex Bolt (1000pk)", currentDemand: 176, forecastedDemand: 180, change: 2.3, confidence: 94, trend: "stable", suggestedOrder: 220 },
  { sku: "EL-4401-GR", name: "Wireless Earbuds Pro", currentDemand: 164, forecastedDemand: 241, change: 47.0, confidence: 78, trend: "up", suggestedOrder: 600 },
  { sku: "AP-8812-BL", name: "Waterproof Jacket M", currentDemand: 122, forecastedDemand: 198, change: 62.3, confidence: 72, trend: "up", suggestedOrder: 400 },
];

const seasonalFactors = [
  { factor: "Holiday Season (Nov–Dec)", impact: "+38%", color: "#10b981" },
  { factor: "Summer Slump (Jul–Aug)", impact: "+12%", color: "#06b6d4" },
  { factor: "Back-to-School (Aug–Sep)", impact: "+22%", color: "#8b5cf6" },
  { factor: "Post-Holiday Dip (Jan–Feb)", impact: "−15%", color: "#ef4444" },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-xl p-3 shadow-xl" style={{ fontSize: "0.78rem" }}>
        <p className="text-muted-foreground mb-2 pb-1 border-b border-border">{label}</p>
        {payload.map((p: any, i: number) => p.value !== null && (
          <div key={i} className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
            <span className="text-foreground">{p.name}: <span style={{ color: p.color, fontFamily: "var(--font-mono)" }}>{p.value?.toLocaleString()}</span></span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export function DemandForecast() {
  const [horizon, setHorizon] = useState<"3m" | "6m" | "12m">("12m");
  const [model, setModel] = useState("ARIMA + ML Ensemble");

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-foreground" style={{ fontSize: "1.4rem", fontWeight: 700 }}>Demand Forecasting</h1>
          <p className="text-muted-foreground" style={{ fontSize: "0.85rem", marginTop: "2px" }}>AI-powered demand prediction with confidence intervals</p>
        </div>
        <div className="flex items-center gap-2 bg-card border border-border rounded-xl px-3 py-2">
          <Brain className="w-4 h-4 text-primary" />
          <span style={{ fontSize: "0.78rem", color: "#94a3b8" }}>Model: </span>
          <span style={{ fontSize: "0.78rem", color: "#06b6d4", fontWeight: 500 }}>{model}</span>
        </div>
      </div>

      {/* Model stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Forecast Accuracy", value: "94.2%", sub: "MAPE: 5.8%", color: "#10b981" },
          { label: "Avg Confidence", value: "84%", sub: "Across all SKUs", color: "#06b6d4" },
          { label: "Items Forecasted", value: "12,847", sub: "Full catalog", color: "#8b5cf6" },
          { label: "Last Retrained", value: "3h ago", sub: "Next: in 21h", color: "#f59e0b" },
        ].map(stat => (
          <div key={stat.label} className="bg-card border border-border rounded-xl p-4">
            <p className="text-muted-foreground" style={{ fontSize: "0.75rem" }}>{stat.label}</p>
            <p style={{ fontFamily: "var(--font-mono)", fontSize: "1.4rem", fontWeight: 700, color: stat.color, lineHeight: 1.2, marginTop: "4px" }}>{stat.value}</p>
            <p className="text-muted-foreground" style={{ fontSize: "0.7rem", marginTop: "4px" }}>{stat.sub}</p>
          </div>
        ))}
      </div>

      {/* Main Forecast Chart */}
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-foreground" style={{ fontSize: "0.95rem", fontWeight: 600 }}>Aggregate Demand Forecast — 2026</h3>
            <p className="text-muted-foreground" style={{ fontSize: "0.78rem" }}>Actual vs. forecasted units with 90% confidence band</p>
          </div>
          <div className="flex gap-1">
            {(["3m", "6m", "12m"] as const).map(h => (
              <button
                key={h}
                onClick={() => setHorizon(h)}
                className={`px-3 py-1.5 rounded-lg border transition-colors ${horizon === h ? "bg-primary/20 border-primary/30 text-primary" : "border-border text-muted-foreground hover:text-foreground"}`}
                style={{ fontSize: "0.75rem" }}
              >
                {h}
              </button>
            ))}
          </div>
        </div>
        <ResponsiveContainer width="100%" height={280}>
          <ComposedChart data={forecastData}>
            <defs>
              <linearGradient id="forecastGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(6,182,212,0.08)" />
            <XAxis dataKey="period" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine x="Jun" stroke="#06b6d4" strokeDasharray="4 2" opacity={0.4} label={{ value: "Today", fill: "#06b6d4", fontSize: 11 }} />
            <Bar dataKey="upper" name="Upper CI" fill="rgba(6,182,212,0.08)" radius={[2,2,0,0]} />
            <Bar dataKey="lower" name="Lower CI" fill="rgba(6,182,212,0.04)" radius={[2,2,0,0]} />
            <Line type="monotone" dataKey="actual" name="Actual" stroke="#10b981" strokeWidth={2.5} dot={{ fill: "#10b981", r: 3 }} connectNulls={false} />
            <Line type="monotone" dataKey="forecast" name="Forecast" stroke="#06b6d4" strokeWidth={2} strokeDasharray="6 3" dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* SKU-Level Forecasts */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="text-foreground mb-4" style={{ fontSize: "0.95rem", fontWeight: 600 }}>SKU-Level Forecast & Procurement Signals</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                {["SKU", "Product", "Current Demand", "Q3 Forecast", "Change", "Confidence", "Suggested Order"].map(h => (
                  <th key={h} className="text-left text-muted-foreground pb-3 pr-4" style={{ fontSize: "0.72rem", textTransform: "uppercase", letterSpacing: "0.05em", fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {skuForecasts.map(item => {
                const TrendIcon = item.trend === "up" ? TrendingUp : item.trend === "down" ? TrendingDown : Minus;
                const trendColor = item.trend === "up" ? "#10b981" : item.trend === "down" ? "#ef4444" : "#64748b";
                return (
                  <tr key={item.sku} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                    <td className="py-3.5 pr-4">
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.73rem", color: "#06b6d4" }}>{item.sku}</span>
                    </td>
                    <td className="py-3.5 pr-4 text-foreground" style={{ fontSize: "0.83rem" }}>{item.name}</td>
                    <td className="py-3.5 pr-4">
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.83rem", color: "#94a3b8" }}>{item.currentDemand}/day</span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.83rem", color: "#e8edf7", fontWeight: 600 }}>{item.forecastedDemand}/day</span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <div className="flex items-center gap-1" style={{ color: trendColor }}>
                        <TrendIcon className="w-3.5 h-3.5" />
                        <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.78rem", fontWeight: 500 }}>
                          {item.change > 0 ? "+" : ""}{item.change.toFixed(1)}%
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 pr-4">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 rounded-full bg-secondary overflow-hidden">
                          <div className="h-full rounded-full" style={{ width: `${item.confidence}%`, background: item.confidence > 85 ? "#10b981" : item.confidence > 75 ? "#f59e0b" : "#ef4444" }} />
                        </div>
                        <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.75rem", color: "#94a3b8" }}>{item.confidence}%</span>
                      </div>
                    </td>
                    <td className="py-3.5">
                      <span className="px-2.5 py-1 rounded-lg bg-primary/15 border border-primary/20 text-primary" style={{ fontFamily: "var(--font-mono)", fontSize: "0.75rem", fontWeight: 500 }}>
                        {item.suggestedOrder.toLocaleString()} units
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Seasonal Factors */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="text-foreground mb-4" style={{ fontSize: "0.95rem", fontWeight: 600 }}>Seasonal Impact Factors</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {seasonalFactors.map(f => (
            <div key={f.factor} className="flex items-center justify-between bg-secondary/50 rounded-xl px-4 py-3 border border-border/50">
              <div className="flex items-center gap-3">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <span style={{ fontSize: "0.83rem", color: "#94a3b8" }}>{f.factor}</span>
              </div>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.85rem", fontWeight: 600, color: f.color }}>{f.impact}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
