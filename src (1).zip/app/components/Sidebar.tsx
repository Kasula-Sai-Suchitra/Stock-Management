import {
  LayoutDashboard,
  Package,
  TrendingUp,
  Truck,
  Bell,
  FileBarChart,
  Settings,
  ChevronRight,
  Boxes,
  Zap,
} from "lucide-react";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", id: "dashboard" },
  { icon: Package, label: "Stock Monitor", id: "stock" },
  { icon: TrendingUp, label: "Demand Forecast", id: "demand" },
  { icon: Truck, label: "Suppliers", id: "suppliers" },
  { icon: Bell, label: "Alerts & Reports", id: "alerts" },
  { icon: FileBarChart, label: "Analytics", id: "analytics" },
];

interface SidebarProps {
  active: string;
  onNavigate: (id: string) => void;
}

export function Sidebar({ active, onNavigate }: SidebarProps) {
  return (
    <aside className="flex flex-col w-64 min-h-screen bg-sidebar border-r border-sidebar-border shrink-0">
      {/* Logo */}
      <div className="flex items-center gap-3 px-6 py-5 border-b border-sidebar-border">
        <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-primary/20 border border-primary/30">
          <Boxes className="w-5 h-5 text-primary" />
        </div>
        <div>
          <p className="text-foreground leading-none" style={{ fontWeight: 600, fontSize: "0.875rem" }}>ChainSight</p>
          <p className="text-muted-foreground" style={{ fontSize: "0.7rem", marginTop: "2px" }}>Supply Chain OS</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        <p className="text-muted-foreground px-3 mb-3 uppercase tracking-widest" style={{ fontSize: "0.65rem" }}>
          Main Menu
        </p>
        {navItems.map(({ icon: Icon, label, id }) => {
          const isActive = active === id;
          return (
            <button
              key={id}
              onClick={() => onNavigate(id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-150 group ${
                isActive
                  ? "bg-primary/15 text-primary border border-primary/20"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground border border-transparent"
              }`}
            >
              <Icon className={`w-4.5 h-4.5 shrink-0 ${isActive ? "text-primary" : "group-hover:text-foreground"}`} style={{ width: "1.1rem", height: "1.1rem" }} />
              <span style={{ fontSize: "0.85rem", fontWeight: isActive ? 500 : 400 }}>{label}</span>
              {isActive && <ChevronRight className="w-3.5 h-3.5 ml-auto text-primary" />}
            </button>
          );
        })}

        <div className="pt-4">
          <p className="text-muted-foreground px-3 mb-3 uppercase tracking-widest" style={{ fontSize: "0.65rem" }}>
            System
          </p>
          <button
            onClick={() => onNavigate("settings")}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-150 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground border border-transparent`}
          >
            <Settings style={{ width: "1.1rem", height: "1.1rem" }} />
            <span style={{ fontSize: "0.85rem" }}>Settings</span>
          </button>
        </div>
      </nav>

      {/* Status badge */}
      <div className="px-4 pb-5">
        <div className="flex items-center gap-2.5 bg-secondary rounded-xl px-3.5 py-3 border border-border">
          <div className="relative">
            <div className="w-2 h-2 rounded-full bg-accent" />
            <div className="absolute inset-0 w-2 h-2 rounded-full bg-accent animate-ping opacity-60" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-foreground" style={{ fontSize: "0.78rem", fontWeight: 500 }}>System Operational</p>
            <p className="text-muted-foreground" style={{ fontSize: "0.68rem" }}>All services running</p>
          </div>
          <Zap className="w-3.5 h-3.5 text-accent shrink-0" />
        </div>
      </div>
    </aside>
  );
}
