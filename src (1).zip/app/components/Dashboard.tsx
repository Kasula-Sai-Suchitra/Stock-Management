import {
  Package,
  TrendingUp,
  TrendingDown,
  Truck,
  AlertTriangle,
  DollarSign,
  RefreshCw,
  ArrowUpRight,
  ArrowDownRight,
  ShoppingCart,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

const kpiData = [
  {
    label: "Total SKUs",
    value: "12,847",
    change: "+3.2%",
    positive: true,
    icon: Package,
    color: "#06b6d4",
    bg: "rgba(6,182,212,0.1)",
  },
  {
    label: "Revenue (MTD)",
    value: "$2.84M",
    change: "+8.7%",
    positive: true,
    icon: DollarSign,
    color: "#10b981",
    bg: "rgba(16,185,129,0.1)",
  },
  {
    label: "Active Suppliers",
    value: "284",
    change: "+12",
    positive: true,
    icon: Truck,
    color: "#8b5cf6",
    bg: "rgba(139,92,246,0.1)",
  },
  {
    label: "Low Stock Alerts",
    value: "47",
    change: "+9",
    positive: false,
    icon: AlertTriangle,
    color: "#ef4444",
    bg: "rgba(239,68,68,0.1)",
  },
  {
    label: "Orders Today",
    value: "1,293",
    change: "+5.1%",
    positive: true,
    icon: ShoppingCart,
    color: "#f59e0b",
    bg: "rgba(245,158,11,0.1)",
  },
  {
    label: "Fulfillment Rate",
    value: "97.3%",
    change: "-0.4%",
    positive: false,
    icon: RefreshCw,
    color: "#06b6d4",
    bg: "rgba(6,182,212,0.1)",
  },
];

const stockTrendData = [
  { month: "Jan", inbound: 4200, outbound: 3800, onHand: 18400 },
  { month: "Feb", inbound: 3800, outbound: 4100, onHand: 18100 },
  { month: "Mar", inbound: 5200, outbound: 4400, onHand: 18900 },
  { month: "Apr", inbound: 4600, outbound: 5100, onHand: 18400 },
  { month: "May", inbound: 6100, outbound: 4800, onHand: 19700 },
  { month: "Jun", inbound: 5400, outbound: 5600, onHand: 19500 },
  { month: "Jul", inbound: 7200, outbound: 6100, onHand: 20600 },
  { month: "Aug", inbound: 6400, outbound: 6800, onHand: 20200 },
  { month: "Sep", inbound: 5800, outbound: 5200, onHand: 20800 },
  { month: "Oct", inbound: 7600, outbound: 6400, onHand: 22000 },
  { month: "Nov", inbound: 8200, outbound: 7100, onHand: 23100 },
  { month: "Dec", inbound: 9100, outbound: 8400, onHand: 23800 },
];

const categoryData = [
  { name: "Electronics", value: 32, fill: "#06b6d4" },
  { name: "Apparel", value: 22, fill: "#10b981" },
  { name: "Food & Bev", value: 18, fill: "#f59e0b" },
  { name: "Industrial", value: 16, fill: "#8b5cf6" },
  { name: "Other", value: 12, fill: "#64748b" },
];

const topMovers = [
  { sku: "EL-9284-BK", name: "Laptop Pro 15\"", category: "Electronics", velocity: 284, trend: "up" },
  { sku: "AP-3341-SM", name: "Running Shorts XS-XL", category: "Apparel", velocity: 241, trend: "up" },
  { sku: "FB-0022-CS", name: "Cold Brew Coffee 12pk", category: "Food & Bev", velocity: 198, trend: "down" },
  { sku: "IN-7731-MT", name: "M8 Hex Bolt (1000pk)", category: "Industrial", velocity: 176, trend: "up" },
  { sku: "EL-5512-WH", name: "USB-C Hub 7-Port", category: "Electronics", velocity: 164, trend: "up" },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-xl p-3 shadow-xl" style={{ fontSize: "0.78rem" }}>
        <p className="text-muted-foreground mb-2">{label}</p>
        {payload.map((p: any, i: number) => (
          <div key={i} className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
            <span className="text-foreground">{p.name}: <span style={{ color: p.color, fontFamily: "var(--font-mono)" }}>{p.value.toLocaleString()}</span></span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-foreground" style={{ fontSize: "1.4rem", fontWeight: 700 }}>Operations Dashboard</h1>
          <p className="text-muted-foreground" style={{ fontSize: "0.85rem", marginTop: "2px" }}>
            Real-time overview — <span style={{ fontFamily: "var(--font-mono)", color: "#06b6d4" }}>Monday, June 16 2026</span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary border border-border text-muted-foreground hover:text-foreground transition-colors" style={{ fontSize: "0.8rem" }}>
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary/20 border border-primary/30 text-primary hover:bg-primary/30 transition-colors" style={{ fontSize: "0.8rem", fontWeight: 500 }}>
            Export Report
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {kpiData.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div
              key={kpi.label}
              className="bg-card border border-border rounded-xl p-5 hover:border-primary/20 transition-all duration-200 hover:shadow-lg"
              style={{ boxShadow: "0 0 0 0 transparent" }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center justify-center w-9 h-9 rounded-lg" style={{ background: kpi.bg }}>
                  <Icon style={{ width: "1rem", height: "1rem", color: kpi.color }} />
                </div>
                <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full`} style={{
                  background: kpi.positive ? "rgba(16,185,129,0.1)" : "rgba(239,68,68,0.1)",
                  fontSize: "0.72rem",
                  fontWeight: 500,
                  color: kpi.positive ? "#10b981" : "#ef4444",
                  fontFamily: "var(--font-mono)",
                }}>
                  {kpi.positive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {kpi.change}
                </div>
              </div>
              <p className="text-foreground" style={{ fontSize: "1.6rem", fontWeight: 700, lineHeight: 1, fontFamily: "var(--font-mono)" }}>{kpi.value}</p>
              <p className="text-muted-foreground mt-1" style={{ fontSize: "0.78rem" }}>{kpi.label}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Stock Trend */}
        <div className="lg:col-span-2 bg-card border border-border rounded-xl p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-foreground" style={{ fontSize: "0.95rem", fontWeight: 600 }}>Inventory Flow</h3>
              <p className="text-muted-foreground" style={{ fontSize: "0.78rem" }}>Inbound vs Outbound vs On-Hand (2026)</p>
            </div>
            <div className="flex gap-3" style={{ fontSize: "0.72rem" }}>
              {[
                { label: "Inbound", color: "#06b6d4" },
                { label: "Outbound", color: "#ef4444" },
                { label: "On-Hand", color: "#10b981" },
              ].map((l) => (
                <div key={l.label} className="flex items-center gap-1.5 text-muted-foreground">
                  <div className="w-2.5 h-2.5 rounded-sm" style={{ background: l.color }} />
                  {l.label}
                </div>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={stockTrendData}>
              <defs>
                <linearGradient id="inboundGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="outboundGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(6,182,212,0.08)" />
              <XAxis dataKey="month" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v/1000).toFixed(0)}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="inbound" name="Inbound" stroke="#06b6d4" strokeWidth={2} fill="url(#inboundGrad)" />
              <Area type="monotone" dataKey="outbound" name="Outbound" stroke="#ef4444" strokeWidth={2} fill="url(#outboundGrad)" />
              <Area type="monotone" dataKey="onHand" name="On-Hand" stroke="#10b981" strokeWidth={2} fill="none" strokeDasharray="4 2" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Category Breakdown */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h3 className="text-foreground mb-1" style={{ fontSize: "0.95rem", fontWeight: 600 }}>Stock by Category</h3>
          <p className="text-muted-foreground mb-4" style={{ fontSize: "0.78rem" }}>Share of total SKUs</p>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={categoryData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              <Tooltip formatter={(v: any) => [`${v}%`, "Share"]} contentStyle={{ background: "#0d1424", border: "1px solid rgba(6,182,212,0.2)", borderRadius: "0.5rem", fontSize: "0.78rem" }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {categoryData.map((cat) => (
              <div key={cat.name} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ background: cat.fill }} />
                <span className="text-muted-foreground flex-1" style={{ fontSize: "0.75rem" }}>{cat.name}</span>
                <span style={{ fontSize: "0.75rem", fontFamily: "var(--font-mono)", color: cat.fill }}>{cat.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Movers */}
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-foreground" style={{ fontSize: "0.95rem", fontWeight: 600 }}>Top Moving SKUs</h3>
          <span className="text-muted-foreground" style={{ fontSize: "0.78rem" }}>Units/day velocity</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                {["SKU", "Product", "Category", "Velocity", "Trend"].map((h) => (
                  <th key={h} className="text-left text-muted-foreground pb-3 pr-4" style={{ fontSize: "0.72rem", textTransform: "uppercase", letterSpacing: "0.05em", fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {topMovers.map((item, i) => (
                <tr key={item.sku} className="border-b border-border/50 hover:bg-secondary/50 transition-colors">
                  <td className="py-3 pr-4">
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.75rem", color: "#06b6d4" }}>{item.sku}</span>
                  </td>
                  <td className="py-3 pr-4 text-foreground" style={{ fontSize: "0.83rem" }}>{item.name}</td>
                  <td className="py-3 pr-4">
                    <span className="px-2 py-0.5 rounded-md bg-secondary text-muted-foreground" style={{ fontSize: "0.72rem" }}>{item.category}</span>
                  </td>
                  <td className="py-3 pr-4">
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 rounded-full bg-secondary overflow-hidden" style={{ width: "60px" }}>
                        <div className="h-full rounded-full bg-primary" style={{ width: `${(item.velocity / 284) * 100}%` }} />
                      </div>
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.78rem", color: "#e8edf7" }}>{item.velocity}</span>
                    </div>
                  </td>
                  <td className="py-3">
                    {item.trend === "up"
                      ? <TrendingUp className="w-4 h-4 text-accent" />
                      : <TrendingDown className="w-4 h-4 text-destructive" />
                    }
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
