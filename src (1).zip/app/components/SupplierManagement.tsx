import { useState } from "react";
import { Star, Phone, Mail, Globe, ChevronDown, ChevronUp, Plus, Search, MapPin, Package } from "lucide-react";
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, Tooltip } from "recharts";

const suppliers = [
  {
    id: "SUP-001",
    name: "TechSource Asia Pacific",
    country: "Taiwan",
    flag: "🇹🇼",
    category: "Electronics",
    contact: "Michael Chen",
    email: "m.chen@techsource-ap.com",
    phone: "+886 2 2345 6789",
    website: "techsource-ap.com",
    rating: 4.8,
    onTimeDelivery: 97,
    qualityScore: 95,
    priceCompetitiveness: 88,
    communication: 92,
    flexibility: 85,
    activeOrders: 8,
    totalSpend: 2840000,
    leadTime: 14,
    status: "preferred",
    certifications: ["ISO 9001", "RoHS", "CE"],
  },
  {
    id: "SUP-002",
    name: "GlobalThread Co.",
    country: "Bangladesh",
    flag: "🇧🇩",
    category: "Apparel",
    contact: "Rashida Akter",
    email: "r.akter@globalthread.com",
    phone: "+880 2 9876 5432",
    website: "globalthread.com",
    rating: 4.2,
    onTimeDelivery: 89,
    qualityScore: 87,
    priceCompetitiveness: 96,
    communication: 78,
    flexibility: 82,
    activeOrders: 12,
    totalSpend: 1240000,
    leadTime: 28,
    status: "approved",
    certifications: ["GOTS", "OEKO-TEX", "BSCI"],
  },
  {
    id: "SUP-003",
    name: "NatureBrew Imports",
    country: "Colombia",
    flag: "🇨🇴",
    category: "Food & Bev",
    contact: "Carlos Rivera",
    email: "c.rivera@naturebrew.co",
    phone: "+57 1 234 5678",
    website: "naturebrew.co",
    rating: 4.5,
    onTimeDelivery: 93,
    qualityScore: 96,
    priceCompetitiveness: 82,
    communication: 90,
    flexibility: 88,
    activeOrders: 5,
    totalSpend: 890000,
    leadTime: 21,
    status: "preferred",
    certifications: ["Organic", "Fair Trade", "Rainforest Alliance"],
  },
  {
    id: "SUP-004",
    name: "Ironworks Industrial",
    country: "Germany",
    flag: "🇩🇪",
    category: "Industrial",
    contact: "Klaus Müller",
    email: "k.muller@ironworks-de.eu",
    phone: "+49 89 1234 5678",
    website: "ironworks-de.eu",
    rating: 4.9,
    onTimeDelivery: 99,
    qualityScore: 99,
    priceCompetitiveness: 72,
    communication: 95,
    flexibility: 78,
    activeOrders: 3,
    totalSpend: 560000,
    leadTime: 7,
    status: "preferred",
    certifications: ["ISO 9001", "DIN", "TÜV"],
  },
  {
    id: "SUP-005",
    name: "FastFab Electronics",
    country: "China",
    flag: "🇨🇳",
    category: "Electronics",
    contact: "Wei Zhang",
    email: "w.zhang@fastfab.cn",
    phone: "+86 755 8765 4321",
    website: "fastfab-electronics.cn",
    rating: 3.8,
    onTimeDelivery: 78,
    qualityScore: 80,
    priceCompetitiveness: 98,
    communication: 70,
    flexibility: 90,
    activeOrders: 6,
    totalSpend: 420000,
    leadTime: 18,
    status: "under-review",
    certifications: ["ISO 9001"],
  },
];

const statusConfig = {
  preferred: { label: "Preferred", color: "#10b981", bg: "rgba(16,185,129,0.1)" },
  approved: { label: "Approved", color: "#06b6d4", bg: "rgba(6,182,212,0.1)" },
  "under-review": { label: "Under Review", color: "#f59e0b", bg: "rgba(245,158,11,0.1)" },
  suspended: { label: "Suspended", color: "#ef4444", bg: "rgba(239,68,68,0.1)" },
};

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map(i => (
        <Star
          key={i}
          className="w-3 h-3"
          style={{ color: i <= Math.round(rating) ? "#f59e0b" : "#334155", fill: i <= Math.round(rating) ? "#f59e0b" : "none" }}
        />
      ))}
      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.75rem", color: "#94a3b8", marginLeft: "4px" }}>{rating}</span>
    </div>
  );
}

export function SupplierManagement() {
  const [expanded, setExpanded] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  const filtered = suppliers.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-foreground" style={{ fontSize: "1.4rem", fontWeight: 700 }}>Supplier Management</h1>
          <p className="text-muted-foreground" style={{ fontSize: "0.85rem", marginTop: "2px" }}>Track and evaluate your supplier network</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary/20 border border-primary/30 text-primary hover:bg-primary/30 transition-colors" style={{ fontSize: "0.83rem", fontWeight: 500 }}>
          <Plus className="w-4 h-4" />
          Add Supplier
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Suppliers", value: "284", color: "#06b6d4" },
          { label: "Preferred", value: "94", color: "#10b981" },
          { label: "Under Review", value: "23", color: "#f59e0b" },
          { label: "Total Spend YTD", value: "$8.4M", color: "#8b5cf6" },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border rounded-xl p-4">
            <p className="text-muted-foreground" style={{ fontSize: "0.75rem" }}>{s.label}</p>
            <p style={{ fontFamily: "var(--font-mono)", fontSize: "1.5rem", fontWeight: 700, color: s.color, lineHeight: 1.2, marginTop: "4px" }}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="flex items-center gap-2 bg-card border border-border rounded-lg px-3 py-2">
        <Search className="w-4 h-4 text-muted-foreground" />
        <input
          className="bg-transparent outline-none text-foreground placeholder-muted-foreground flex-1"
          style={{ fontSize: "0.83rem" }}
          placeholder="Search suppliers by name or category..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* Supplier Cards */}
      <div className="space-y-3">
        {filtered.map(supplier => {
          const isOpen = expanded === supplier.id;
          const cfg = statusConfig[supplier.status as keyof typeof statusConfig];
          const radarData = [
            { metric: "On-Time", value: supplier.onTimeDelivery },
            { metric: "Quality", value: supplier.qualityScore },
            { metric: "Price", value: supplier.priceCompetitiveness },
            { metric: "Comms", value: supplier.communication },
            { metric: "Flexibility", value: supplier.flexibility },
          ];

          return (
            <div key={supplier.id} className="bg-card border border-border rounded-xl overflow-hidden transition-all duration-200 hover:border-primary/20">
              {/* Header row */}
              <div
                className="flex items-center gap-4 p-5 cursor-pointer"
                onClick={() => setExpanded(isOpen ? null : supplier.id)}
              >
                <div className="flex items-center justify-center w-11 h-11 rounded-xl bg-secondary border border-border shrink-0" style={{ fontSize: "1.4rem" }}>
                  {supplier.flag}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-foreground" style={{ fontSize: "0.9rem", fontWeight: 600 }}>{supplier.name}</span>
                    <span className="px-2 py-0.5 rounded-md bg-secondary text-muted-foreground" style={{ fontSize: "0.7rem" }}>{supplier.category}</span>
                    <span className="px-2 py-0.5 rounded-md" style={{ fontSize: "0.7rem", color: cfg.color, background: cfg.bg, fontWeight: 500 }}>{cfg.label}</span>
                  </div>
                  <div className="flex items-center gap-3 mt-1 flex-wrap">
                    <div className="flex items-center gap-1 text-muted-foreground" style={{ fontSize: "0.75rem" }}>
                      <MapPin className="w-3 h-3" />
                      {supplier.country}
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground" style={{ fontSize: "0.75rem" }}>
                      <Package className="w-3 h-3" />
                      {supplier.activeOrders} active orders
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-6 shrink-0">
                  <div className="text-right hidden lg:block">
                    <StarRating rating={supplier.rating} />
                    <p className="text-muted-foreground mt-1" style={{ fontSize: "0.72rem" }}>Lead time: <span style={{ fontFamily: "var(--font-mono)", color: "#06b6d4" }}>{supplier.leadTime}d</span></p>
                  </div>
                  <div className="text-right hidden lg:block">
                    <p style={{ fontFamily: "var(--font-mono)", fontSize: "0.95rem", fontWeight: 700, color: "#e8edf7" }}>${(supplier.totalSpend / 1000000).toFixed(2)}M</p>
                    <p className="text-muted-foreground" style={{ fontSize: "0.72rem" }}>Total spend</p>
                  </div>
                  {isOpen ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                </div>
              </div>

              {/* Expanded detail */}
              {isOpen && (
                <div className="border-t border-border px-5 pb-5 pt-4 grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Contact info */}
                  <div className="space-y-3">
                    <p className="text-muted-foreground uppercase tracking-widest" style={{ fontSize: "0.65rem" }}>Contact Details</p>
                    <div>
                      <p className="text-foreground" style={{ fontSize: "0.85rem", fontWeight: 500 }}>{supplier.contact}</p>
                    </div>
                    <div className="space-y-2">
                      {[
                        { icon: Mail, label: supplier.email },
                        { icon: Phone, label: supplier.phone },
                        { icon: Globe, label: supplier.website },
                      ].map(({ icon: Icon, label }) => (
                        <div key={label} className="flex items-center gap-2 text-muted-foreground" style={{ fontSize: "0.78rem" }}>
                          <Icon className="w-3.5 h-3.5 shrink-0" />
                          <span>{label}</span>
                        </div>
                      ))}
                    </div>
                    <div>
                      <p className="text-muted-foreground uppercase tracking-widest mb-2" style={{ fontSize: "0.65rem" }}>Certifications</p>
                      <div className="flex flex-wrap gap-1.5">
                        {supplier.certifications.map(cert => (
                          <span key={cert} className="px-2 py-0.5 rounded-md bg-primary/10 border border-primary/20 text-primary" style={{ fontSize: "0.7rem" }}>{cert}</span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Radar chart */}
                  <div>
                    <p className="text-muted-foreground uppercase tracking-widest mb-3" style={{ fontSize: "0.65rem" }}>Performance Scorecard</p>
                    <ResponsiveContainer width="100%" height={180}>
                      <RadarChart data={radarData}>
                        <PolarGrid stroke="rgba(6,182,212,0.15)" />
                        <PolarAngleAxis dataKey="metric" tick={{ fill: "#64748b", fontSize: 11 }} />
                        <Radar name="Score" dataKey="value" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.2} strokeWidth={2} />
                        <Tooltip contentStyle={{ background: "#0d1424", border: "1px solid rgba(6,182,212,0.2)", borderRadius: "0.5rem", fontSize: "0.78rem" }} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>

                  {/* KPIs */}
                  <div>
                    <p className="text-muted-foreground uppercase tracking-widest mb-3" style={{ fontSize: "0.65rem" }}>KPI Breakdown</p>
                    <div className="space-y-3">
                      {[
                        { label: "On-Time Delivery", value: supplier.onTimeDelivery, color: "#10b981" },
                        { label: "Quality Score", value: supplier.qualityScore, color: "#06b6d4" },
                        { label: "Price Competitiveness", value: supplier.priceCompetitiveness, color: "#8b5cf6" },
                        { label: "Communication", value: supplier.communication, color: "#f59e0b" },
                        { label: "Flexibility", value: supplier.flexibility, color: "#94a3b8" },
                      ].map(kpi => (
                        <div key={kpi.label}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-muted-foreground" style={{ fontSize: "0.75rem" }}>{kpi.label}</span>
                            <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.75rem", color: kpi.color }}>{kpi.value}%</span>
                          </div>
                          <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${kpi.value}%`, background: kpi.color, transition: "width 0.5s ease" }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
