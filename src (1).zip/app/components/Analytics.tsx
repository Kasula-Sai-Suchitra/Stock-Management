import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ScatterChart, Scatter, ZAxis } from "recharts";

const monthlyRevenue = [
  { month: "Jan", revenue: 2.1, orders: 8420, returns: 124 },
  { month: "Feb", revenue: 1.9, orders: 7840, returns: 98 },
  { month: "Mar", revenue: 2.6, orders: 9200, returns: 143 },
  { month: "Apr", revenue: 2.4, orders: 8980, returns: 112 },
  { month: "May", revenue: 2.8, orders: 10200, returns: 167 },
  { month: "Jun", revenue: 2.84, orders: 10440, returns: 134 },
];

const fulfillmentData = [
  { day: "Mon", same: 340, next: 820, standard: 1240 },
  { day: "Tue", same: 290, next: 760, standard: 1180 },
  { day: "Wed", same: 410, next: 890, standard: 1320 },
  { day: "Thu", same: 380, next: 950, standard: 1410 },
  { day: "Fri", same: 520, next: 1100, standard: 1580 },
  { day: "Sat", same: 240, next: 580, standard: 880 },
  { day: "Sun", same: 180, next: 420, standard: 640 },
];

const topRegions = [
  { region: "Chicago Metro", orders: 3842, revenue: 984000, growth: 12.4 },
  { region: "Dallas-Fort Worth", orders: 2941, revenue: 741000, growth: 8.1 },
  { region: "Seattle Area", orders: 1824, revenue: 492000, growth: 18.7 },
  { region: "Atlanta MSA", orders: 2102, revenue: 521000, growth: 5.3 },
  { region: "Detroit Metro", orders: 1293, revenue: 328000, growth: -2.1 },
];

export function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-foreground" style={{ fontSize: "1.4rem", fontWeight: 700 }}>Analytics</h1>
        <p className="text-muted-foreground" style={{ fontSize: "0.85rem", marginTop: "2px" }}>Deep-dive supply chain performance metrics</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Revenue */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h3 className="text-foreground mb-1" style={{ fontSize: "0.95rem", fontWeight: 600 }}>Monthly Revenue</h3>
          <p className="text-muted-foreground mb-4" style={{ fontSize: "0.78rem" }}>$ millions, 2026 YTD</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={monthlyRevenue}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(6,182,212,0.08)" />
              <XAxis dataKey="month" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}M`} />
              <Tooltip contentStyle={{ background: "#0d1424", border: "1px solid rgba(6,182,212,0.2)", borderRadius: "0.5rem", fontSize: "0.78rem" }} formatter={(v: any) => [`$${v}M`]} />
              <Bar dataKey="revenue" name="Revenue" fill="#06b6d4" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Fulfillment by shipping type */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h3 className="text-foreground mb-1" style={{ fontSize: "0.95rem", fontWeight: 600 }}>Fulfillment by Shipping Type</h3>
          <p className="text-muted-foreground mb-4" style={{ fontSize: "0.78rem" }}>Orders per day this week</p>
          <div className="flex gap-3 mb-3" style={{ fontSize: "0.72rem" }}>
            {[{ label: "Same Day", color: "#06b6d4" }, { label: "Next Day", color: "#8b5cf6" }, { label: "Standard", color: "#10b981" }].map(l => (
              <div key={l.label} className="flex items-center gap-1.5 text-muted-foreground">
                <div className="w-2.5 h-2.5 rounded-sm" style={{ background: l.color }} />
                {l.label}
              </div>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={165}>
            <BarChart data={fulfillmentData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(6,182,212,0.08)" />
              <XAxis dataKey="day" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "#0d1424", border: "1px solid rgba(6,182,212,0.2)", borderRadius: "0.5rem", fontSize: "0.78rem" }} />
              <Bar dataKey="same" name="Same Day" stackId="a" fill="#06b6d4" />
              <Bar dataKey="next" name="Next Day" stackId="a" fill="#8b5cf6" />
              <Bar dataKey="standard" name="Standard" stackId="a" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Regional Performance */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="text-foreground mb-4" style={{ fontSize: "0.95rem", fontWeight: 600 }}>Regional Performance</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                {["Region", "Orders (MTD)", "Revenue (MTD)", "Growth", "Share"].map(h => (
                  <th key={h} className="text-left text-muted-foreground pb-3 pr-4" style={{ fontSize: "0.72rem", textTransform: "uppercase", letterSpacing: "0.05em", fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {topRegions.map(r => {
                const totalOrders = topRegions.reduce((s, x) => s + x.orders, 0);
                const share = ((r.orders / totalOrders) * 100).toFixed(1);
                return (
                  <tr key={r.region} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                    <td className="py-3.5 pr-4 text-foreground" style={{ fontSize: "0.83rem", fontWeight: 500 }}>{r.region}</td>
                    <td className="py-3.5 pr-4">
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.83rem", color: "#e8edf7" }}>{r.orders.toLocaleString()}</span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.83rem", color: "#e8edf7" }}>${(r.revenue / 1000).toFixed(0)}k</span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.78rem", fontWeight: 600, color: r.growth >= 0 ? "#10b981" : "#ef4444" }}>
                        {r.growth >= 0 ? "+" : ""}{r.growth}%
                      </span>
                    </td>
                    <td className="py-3.5">
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-1.5 rounded-full bg-secondary overflow-hidden">
                          <div className="h-full rounded-full bg-primary" style={{ width: `${parseFloat(share)}%` }} />
                        </div>
                        <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.72rem", color: "#64748b" }}>{share}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
