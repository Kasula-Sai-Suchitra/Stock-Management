import { useState } from "react";
import { Search, Filter, AlertTriangle, CheckCircle, Clock, Package, ChevronUp, ChevronDown } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";

const stockItems = [
  { id: "EL-9284-BK", name: "Laptop Pro 15\"", category: "Electronics", warehouse: "WH-01 Chicago", onHand: 842, reorderPoint: 200, maxCapacity: 1200, onOrder: 400, status: "healthy", unitCost: 1240 },
  { id: "EL-5512-WH", name: "USB-C Hub 7-Port", category: "Electronics", warehouse: "WH-02 Dallas", onHand: 141, reorderPoint: 150, maxCapacity: 800, onOrder: 300, status: "low", unitCost: 34 },
  { id: "AP-3341-SM", name: "Running Shorts XS-XL", category: "Apparel", warehouse: "WH-01 Chicago", onHand: 2480, reorderPoint: 500, maxCapacity: 3000, onOrder: 0, status: "healthy", unitCost: 22 },
  { id: "AP-8812-BL", name: "Waterproof Jacket M", category: "Apparel", warehouse: "WH-03 Seattle", onHand: 48, reorderPoint: 100, maxCapacity: 600, onOrder: 200, status: "critical", unitCost: 89 },
  { id: "FB-0022-CS", name: "Cold Brew Coffee 12pk", category: "Food & Bev", warehouse: "WH-04 Atlanta", onHand: 1820, reorderPoint: 400, maxCapacity: 2000, onOrder: 0, status: "healthy", unitCost: 28 },
  { id: "FB-3310-TR", name: "Protein Bar Variety 30pk", category: "Food & Bev", warehouse: "WH-04 Atlanta", onHand: 95, reorderPoint: 200, maxCapacity: 1500, onOrder: 500, status: "low", unitCost: 45 },
  { id: "IN-7731-MT", name: "M8 Hex Bolt (1000pk)", category: "Industrial", warehouse: "WH-05 Detroit", onHand: 312, reorderPoint: 100, maxCapacity: 1000, onOrder: 0, status: "healthy", unitCost: 18 },
  { id: "IN-2290-ST", name: "Steel Cable 10mm 50m", category: "Industrial", warehouse: "WH-05 Detroit", onHand: 12, reorderPoint: 50, maxCapacity: 300, onOrder: 100, status: "critical", unitCost: 142 },
  { id: "EL-4401-GR", name: "Wireless Earbuds Pro", category: "Electronics", warehouse: "WH-02 Dallas", onHand: 524, reorderPoint: 150, maxCapacity: 1000, onOrder: 0, status: "healthy", unitCost: 89 },
  { id: "AP-5510-RD", name: "Yoga Mat Premium 6mm", category: "Apparel", warehouse: "WH-03 Seattle", onHand: 378, reorderPoint: 100, maxCapacity: 600, onOrder: 0, status: "healthy", unitCost: 36 },
];

const warehouseData = [
  { name: "WH-01 Chicago", capacity: 95, used: 72 },
  { name: "WH-02 Dallas", capacity: 80, used: 58 },
  { name: "WH-03 Seattle", capacity: 60, used: 41 },
  { name: "WH-04 Atlanta", capacity: 110, used: 98 },
  { name: "WH-05 Detroit", capacity: 75, used: 34 },
];

const statusConfig = {
  healthy: { label: "Healthy", color: "#10b981", bg: "rgba(16,185,129,0.1)", icon: CheckCircle },
  low: { label: "Low Stock", color: "#f59e0b", bg: "rgba(245,158,11,0.1)", icon: Clock },
  critical: { label: "Critical", color: "#ef4444", bg: "rgba(239,68,68,0.1)", icon: AlertTriangle },
};

export function StockMonitor() {
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [sortField, setSortField] = useState<"name" | "onHand" | "status">("onHand");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");

  const filtered = stockItems
    .filter((item) => {
      const matchSearch = item.name.toLowerCase().includes(search.toLowerCase()) || item.id.toLowerCase().includes(search.toLowerCase());
      const matchStatus = filterStatus === "all" || item.status === filterStatus;
      return matchSearch && matchStatus;
    })
    .sort((a, b) => {
      let av: any = a[sortField], bv: any = b[sortField];
      if (typeof av === "string") av = av.toLowerCase(), bv = bv.toLowerCase();
      return sortDir === "asc" ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1);
    });

  const handleSort = (field: "name" | "onHand" | "status") => {
    if (sortField === field) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortField(field); setSortDir("desc"); }
  };

  const SortIcon = ({ field }: { field: string }) =>
    sortField === field
      ? sortDir === "asc" ? <ChevronUp className="w-3 h-3 text-primary inline ml-1" /> : <ChevronDown className="w-3 h-3 text-primary inline ml-1" />
      : null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-foreground" style={{ fontSize: "1.4rem", fontWeight: 700 }}>Stock Monitor</h1>
        <p className="text-muted-foreground" style={{ fontSize: "0.85rem", marginTop: "2px" }}>Real-time inventory levels across all warehouses</p>
      </div>

      {/* Summary pills */}
      <div className="flex gap-3 flex-wrap">
        {[
          { label: "Total Items", value: stockItems.length, color: "#06b6d4" },
          { label: "Healthy", value: stockItems.filter(i => i.status === "healthy").length, color: "#10b981" },
          { label: "Low Stock", value: stockItems.filter(i => i.status === "low").length, color: "#f59e0b" },
          { label: "Critical", value: stockItems.filter(i => i.status === "critical").length, color: "#ef4444" },
        ].map(pill => (
          <div key={pill.label} className="flex items-center gap-2 bg-card border border-border rounded-xl px-4 py-2.5">
            <div className="w-2 h-2 rounded-full" style={{ background: pill.color }} />
            <span className="text-muted-foreground" style={{ fontSize: "0.78rem" }}>{pill.label}</span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.85rem", fontWeight: 600, color: pill.color }}>{pill.value}</span>
          </div>
        ))}
      </div>

      {/* Warehouse capacity chart */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="text-foreground mb-4" style={{ fontSize: "0.95rem", fontWeight: 600 }}>Warehouse Capacity Utilization</h3>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={warehouseData} layout="vertical" margin={{ left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(6,182,212,0.08)" horizontal={false} />
            <XAxis type="number" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} domain={[0, 120]} />
            <YAxis dataKey="name" type="category" tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} width={120} />
            <Tooltip contentStyle={{ background: "#0d1424", border: "1px solid rgba(6,182,212,0.2)", borderRadius: "0.5rem", fontSize: "0.78rem" }} formatter={(v: any) => [`${v}%`]} />
            <ReferenceLine x={100} stroke="#ef4444" strokeDasharray="4 2" opacity={0.5} />
            <Bar dataKey="used" name="Used %" fill="#06b6d4" radius={[0, 4, 4, 0]} background={{ fill: "rgba(6,182,212,0.06)", radius: [0, 4, 4, 0] }} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="flex items-center gap-2 bg-card border border-border rounded-lg px-3 py-2 flex-1 min-w-48">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            className="bg-transparent outline-none text-foreground placeholder-muted-foreground flex-1"
            style={{ fontSize: "0.83rem" }}
            placeholder="Search SKU or product name..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          {["all", "healthy", "low", "critical"].map(s => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-3 py-2 rounded-lg border transition-colors capitalize ${filterStatus === s ? "bg-primary/20 border-primary/30 text-primary" : "bg-card border-border text-muted-foreground hover:text-foreground"}`}
              style={{ fontSize: "0.78rem" }}
            >
              {s === "all" ? "All" : statusConfig[s as keyof typeof statusConfig].label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-secondary/30">
                {[
                  { label: "SKU", field: null },
                  { label: "Product", field: "name" },
                  { label: "Warehouse", field: null },
                  { label: "On Hand", field: "onHand" },
                  { label: "Stock Level", field: null },
                  { label: "On Order", field: null },
                  { label: "Status", field: "status" },
                  { label: "Value", field: null },
                ].map(({ label, field }) => (
                  <th
                    key={label}
                    className={`text-left text-muted-foreground px-4 py-3 ${field ? "cursor-pointer hover:text-foreground transition-colors" : ""}`}
                    style={{ fontSize: "0.72rem", textTransform: "uppercase", letterSpacing: "0.05em", fontWeight: 500 }}
                    onClick={() => field && handleSort(field as any)}
                  >
                    {label}<SortIcon field={field || ""} />
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((item) => {
                const pct = Math.round((item.onHand / item.maxCapacity) * 100);
                const cfg = statusConfig[item.status as keyof typeof statusConfig];
                const Icon = cfg.icon;
                return (
                  <tr key={item.id} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                    <td className="px-4 py-3.5">
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.73rem", color: "#06b6d4" }}>{item.id}</span>
                    </td>
                    <td className="px-4 py-3.5 text-foreground" style={{ fontSize: "0.83rem", maxWidth: "180px" }}>{item.name}</td>
                    <td className="px-4 py-3.5 text-muted-foreground" style={{ fontSize: "0.78rem" }}>{item.warehouse}</td>
                    <td className="px-4 py-3.5">
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.83rem", color: "#e8edf7", fontWeight: 500 }}>{item.onHand.toLocaleString()}</span>
                    </td>
                    <td className="px-4 py-3.5" style={{ minWidth: "120px" }}>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1.5 rounded-full bg-secondary overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all"
                            style={{
                              width: `${Math.min(pct, 100)}%`,
                              background: pct > 80 ? "#10b981" : pct > 30 ? "#f59e0b" : "#ef4444",
                            }}
                          />
                        </div>
                        <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.7rem", color: "#64748b", minWidth: "32px" }}>{pct}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.78rem", color: item.onOrder > 0 ? "#8b5cf6" : "#64748b" }}>
                        {item.onOrder > 0 ? `+${item.onOrder}` : "—"}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-md w-fit" style={{ background: cfg.bg }}>
                        <Icon className="w-3 h-3" style={{ color: cfg.color }} />
                        <span style={{ fontSize: "0.72rem", color: cfg.color, fontWeight: 500 }}>{cfg.label}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.78rem", color: "#94a3b8" }}>
                        ${(item.onHand * item.unitCost).toLocaleString()}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
