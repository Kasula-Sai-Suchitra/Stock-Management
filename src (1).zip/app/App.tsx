import { useState } from "react";
import { Sidebar } from "./components/Sidebar";
import { Dashboard } from "./components/Dashboard";
import { StockMonitor } from "./components/StockMonitor";
import { DemandForecast } from "./components/DemandForecast";
import { SupplierManagement } from "./components/SupplierManagement";
import { AlertsReports } from "./components/AlertsReports";
import { Analytics } from "./components/Analytics";
import { Bell, Search, User, ChevronDown, Menu, X } from "lucide-react";

{/* MARKER-MAKE-KIT-INVOKED */}

function TopBar({ onMenuToggle, menuOpen }: { onMenuToggle: () => void; menuOpen: boolean }) {
  return (
    <header className="h-14 border-b border-border bg-card/60 backdrop-blur-md flex items-center px-4 gap-3 shrink-0 sticky top-0 z-10">
      <button
        className="lg:hidden flex items-center justify-center w-8 h-8 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
        onClick={onMenuToggle}
      >
        {menuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
      </button>

      <div className="flex items-center gap-2 flex-1 max-w-xs bg-secondary rounded-lg px-3 py-1.5 border border-border">
        <Search className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
        <input
          className="bg-transparent outline-none text-foreground placeholder-muted-foreground flex-1"
          style={{ fontSize: "0.8rem" }}
          placeholder="Search anything..."
        />
        <kbd className="hidden sm:inline text-muted-foreground bg-card border border-border rounded px-1" style={{ fontSize: "0.65rem" }}>⌘K</kbd>
      </div>

      <div className="flex items-center gap-1 ml-auto">
        <button className="relative flex items-center justify-center w-9 h-9 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-destructive" />
        </button>
        <button className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-secondary transition-colors ml-1">
          <div className="w-7 h-7 rounded-full bg-primary/30 border border-primary/40 flex items-center justify-center">
            <User className="w-3.5 h-3.5 text-primary" />
          </div>
          <div className="hidden sm:block text-left">
            <p className="text-foreground" style={{ fontSize: "0.78rem", fontWeight: 500, lineHeight: 1 }}>Alex Morgan</p>
            <p className="text-muted-foreground" style={{ fontSize: "0.65rem", lineHeight: 1.4 }}>Supply Chain Manager</p>
          </div>
          <ChevronDown className="w-3 h-3 text-muted-foreground hidden sm:block" />
        </button>
      </div>
    </header>
  );
}

const pageMap: Record<string, JSX.Element> = {
  dashboard: <Dashboard />,
  stock: <StockMonitor />,
  demand: <DemandForecast />,
  suppliers: <SupplierManagement />,
  alerts: <AlertsReports />,
  analytics: <Analytics />,
  settings: (
    <div className="flex flex-col items-center justify-center h-64 text-center">
      <p className="text-foreground" style={{ fontSize: "1.1rem", fontWeight: 600 }}>Settings</p>
      <p className="text-muted-foreground mt-2" style={{ fontSize: "0.85rem" }}>Configuration panel coming soon.</p>
    </div>
  ),
};

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen bg-background overflow-hidden" style={{ fontFamily: "var(--font-family)" }}>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed lg:relative z-30 lg:z-auto h-full transition-transform duration-200 ${sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <Sidebar
          active={page}
          onNavigate={(id) => {
            setPage(id);
            setSidebarOpen(false);
          }}
        />
      </div>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar onMenuToggle={() => setSidebarOpen(!sidebarOpen)} menuOpen={sidebarOpen} />
        <main className="flex-1 overflow-y-auto p-6">
          {pageMap[page] ?? pageMap["dashboard"]}
        </main>
      </div>
    </div>
  );
}
